/*
 * file:       InvalidCalendarTest.java
 * author:     Jon Iles
 * copyright:  (c) Packwood Software 2015
 * date:       27/02/2015
 */

/*
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 2.1 of the License, or (at your
 * option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */

package org.mpxj.junit.calendar;

import java.io.File;

import org.junit.jupiter.api.Test;
import org.mpxj.MPXJException;
import org.mpxj.ProjectCalendar;
import org.mpxj.ProjectFile;
import org.mpxj.junit.MpxjTestData;
import org.mpxj.primavera.PrimaveraXERFileReader;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Ensure that invalid calendar data is handled gracefully.
 */
public class InvalidCalendarTest
{
   /**
    * Test reading an XER file which contains invalid calendar data.
    */
   @Test public void testInvalidPrimaveraCalendar() throws MPXJException
   {
      File testDataDir = new File(MpxjTestData.filePath("calendar/invalid"));
      File file = new File(testDataDir, "invalid-8.4.xer");
      PrimaveraXERFileReader reader = new PrimaveraXERFileReader();
      ProjectFile project = reader.read(file);

      ProjectCalendar calendar = project.getCalendarByUniqueID(Integer.valueOf(178));
      assertEquals("Corporate - Standard Full Time", calendar.getName());

      calendar = project.getCalendarByUniqueID(Integer.valueOf(179));
      assertEquals("Test - Valid", calendar.getName());

      calendar = project.getCalendarByUniqueID(Integer.valueOf(180));
      assertEquals("Test - Invalid", calendar.getName());
   }
}
